(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,38592,e=>{"use strict";var t=e.i(43476),i=e.i(78583),l=e.i(98919),c=e.i(84614);let s=(0,e.i(75254).default)("circle-alert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]),n=[{icon:c.User,title:"شروط الاستخدام",content:`باستخدامك لتطبيق ZAWAJ AI فإنك توافق على الشروط التالية:

• يجب أن يكون عمرك 18 سنة أو أكثر.
• تلتزم بتقديم معلومات صحيحة ودقيقة في ملفك الشخصي.
• يُحظر استخدام التطبيق لأغراض غير مشروعة أو مخالفة للآداب العامة.
• يُحظر انتحال شخصية أي شخص آخر.
• تلتزم باحترام المستخدمين الآخرين وعدم التحرش أو الإساءة.
• نحتفظ بالحق في تعليق أو حذف أي حساب يخالف هذه الشروط.`},{icon:l.Shield,title:"سياسة الخصوصية",content:`نحن نأخذ خصوصيتك على محمل الجد:

• نجمع فقط البيانات الضرورية لتشغيل الخدمة.
• لا نبيع بياناتك أو نشاركها مع أطراف ثالثة لأغراض تجارية.
• جميع البيانات مشفرة ومحمية بأعلى معايير الأمان.
• يحق لك طلب حذف جميع بياناتك في أي وقت.
• نستخدم Supabase كمزود خدمة قاعدة البيانات الذي يلتزم بمعايير GDPR.
• قد نستخدم بيانات مجهولة الهوية لتحسين الخدمة.`},{icon:i.FileText,title:"سياسة الاسترداد",content:`بخصوص النقاط والمدفوعات:

• النقاط المشتراة غير قابلة للاسترداد بعد إتمام عملية الشراء.
• في حال وجود خطأ تقني من جهتنا، نلتزم باسترداد المبلغ كاملاً.
• يمكن نقل النقاط كهدايا لمستخدمين آخرين.
• تنتهي صلاحية النقاط حسب الباقة المختارة.`},{icon:s,title:"إخلاء المسؤولية",content:`يُقدم ZAWAJ AI منصة للتعارف بهدف الزواج فقط:

• لسنا مسؤولين عن القرارات الشخصية التي يتخذها المستخدمون.
• لا نضمن نتائج معينة من استخدام التطبيق.
• نوصي بالتحقق من هوية أي شخص قبل اللقاء الشخصي.
• الوسطاء مستقلون وليسوا موظفين لدينا.`}];e.s(["default",0,function(){return(0,t.jsxs)("div",{className:"min-h-full px-4 py-6",dir:"rtl",children:[(0,t.jsx)("h1",{className:"text-2xl font-black text-white mb-2",children:"الشروط والسياسات"}),(0,t.jsx)("p",{className:"text-white/40 text-sm mb-6",children:"آخر تحديث: يناير 2026"}),(0,t.jsx)("div",{className:"space-y-4",children:n.map(e=>(0,t.jsxs)("div",{className:"glass-panel p-5",children:[(0,t.jsxs)("h2",{className:"text-white font-black text-sm border-b border-white/10 pb-3 flex items-center gap-2 mb-4",children:[(0,t.jsx)(e.icon,{size:16,className:"text-[#c0002a]"}),e.title]}),(0,t.jsx)("p",{className:"text-white/55 text-sm leading-relaxed whitespace-pre-line",children:e.content})]},e.title))}),(0,t.jsx)("p",{className:"text-white/20 text-[10px] text-center mt-6 pb-4",children:"ZAWAJ AI © 2026 — جميع الحقوق محفوظة"})]})}],38592)}]);